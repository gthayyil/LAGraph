
To run the simple, brute-force method (does not exploit sparsity):

    help hd_orig

and then cut-and-paste that example.

To run the example of the true algorithm, type:

    hexample

